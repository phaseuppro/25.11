jQuery(document).ready(function($) {
    console.log('BuddyPress JS loaded');
    
    $('#photo-file').on('change', function(e) {
        console.log('File selected');
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                console.log('File loaded');
                const preview = document.createElement('div');
                preview.className = 'photo-preview';
                preview.innerHTML = `<img src="${e.target.result}">`;
                
                const existingPreview = document.querySelector('.photo-preview');
                if (existingPreview) {
                    existingPreview.remove();
                }
                
                $(this).parent().append(preview);
            }.bind(this);
            reader.readAsDataURL(file);
        }
    });
});