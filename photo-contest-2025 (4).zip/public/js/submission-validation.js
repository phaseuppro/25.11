jQuery(document).ready(function($) {
    const form = $('.photo-contest-submission-form form');
    const maxFileSize = 5 * 1024 * 1024; // 5MB in bytes

    form.on('submit', function(e) {
        $('.error').remove();
        let hasError = false;

        // Title validation
        const title = $('#photo-title').val().trim();
        if (title.length < 3) {
            $('#photo-title').after('<span class="error">Title must be at least 3 characters long</span>');
            hasError = true;
        }

        // File validation
        const photoFile = $('#photo-file')[0].files[0];
        if (photoFile) {
            if (!photoFile.type.match('image.*')) {
                $('#photo-file').after('<span class="error">Please upload an image file</span>');
                hasError = true;
            }
            if (photoFile.size > maxFileSize) {
                $('#photo-file').after('<span class="error">File size must be less than 5MB</span>');
                hasError = true;
            }
        }

        if (hasError) {
            e.preventDefault();
            return false;
        }

        // Show loading state
        $('.submit-button').prop('disabled', true).text('Uploading...');
    });

    // Preview image before upload
    $('#photo-file').on('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                if ($('.image-preview').length === 0) {
                    $('<div class="image-preview"><img src="' + e.target.result + '"></div>').insertAfter('#photo-file');
                } else {
                    $('.image-preview img').attr('src', e.target.result);
                }
            }
            reader.readAsDataURL(file);
        }
    });
});
