<?php if (!defined('ABSPATH')) exit; ?>

<div class="photo-contest-results">
    <?php if (isset($contest_id)): // Specific contest results ?>
        <h2><?php echo esc_html($contest->title); ?> - Results</h2>
        
        <?php if ($winners): ?>
            <div class="winners-podium">
                <?php foreach ($winners as $position => $winner): ?>
                    <div class="winner position-<?php echo esc_attr($position + 1); ?>">
                        <div class="winner-photo">
                            <img src="<?php echo esc_url($winner->photo_url); ?>" 
                                 alt="<?php echo esc_attr($winner->title); ?>">
                            <span class="position-badge"><?php echo esc_html($position + 1); ?></span>
                        </div>
                        <div class="winner-info">
                            <h3><?php echo esc_html($winner->title); ?></h3>
                            <p class="photographer">By <?php echo esc_html(get_userdata($winner->user_id)->display_name); ?></p>
                            <p class="votes"><?php echo esc_html($winner->votes_count); ?> votes</p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="no-results">No results available yet.</p>
        <?php endif; ?>
        
    <?php else: // Overall results page ?>
        <h2><?php _e('Contest Results', 'photo-contest'); ?></h2>
        
        <?php if (!empty($results)): ?>
            <div class="contest-results-grid">
                <?php foreach ($results as $result): ?>
                    <div class="contest-entry">
                        <div class="entry-photo">
                            <img src="<?php echo esc_url($result->photo_url); ?>" 
                                 alt="<?php echo esc_attr($result->title); ?>">
                        </div>
                        <div class="entry-info">
                            <h3><?php echo esc_html($result->title); ?></h3>
                            <p class="contest-name"><?php echo esc_html($result->contest_title); ?></p>
                            <p class="photographer">By <?php echo esc_html($result->display_name); ?></p>
                            <p class="votes"><?php echo esc_html($result->votes); ?> votes</p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="no-results"><?php _e('No contest results available.', 'photo-contest'); ?></p>
        <?php endif; ?>
    <?php endif; ?>
</div>
