<?php if (!defined('ABSPATH')) exit; ?>

<div class="photo-contest-submission-form">
    <h2>Submit Your Photo</h2>
    
    <form id="photo-contest-form" method="post" enctype="multipart/form-data">
        <input type="hidden" name="action" value="submit_contest_photo">
        <?php wp_nonce_field('photo_contest_submission', 'submission_nonce'); ?>

        <div class="form-field">
            <label for="photo-title">Photo Title *</label>
            <input type="text" id="photo-title" name="photo_title" required>
        </div>

        <div class="form-field">
            <label for="photo-file">Upload Photo *</label>
            <input type="file" id="photo-file" name="photo" accept="image/*" required>
        </div>

        <button type="submit" class="submit-button">Submit Photo</button>
    </form>
</div>
