<?php
/**
 * Plugin Name: Photo Contest 2025
 * Plugin URI: https://yourwebsite.com/photo-contest
 * Description: Modern photo contest plugin with voting system
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: photo-contest
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('PHOTO_CONTEST_VERSION', '1.0.0');
define('PHOTO_CONTEST_PATH', plugin_dir_path(__FILE__));
define('PHOTO_CONTEST_URL', plugin_dir_url(__FILE__));

// Register image sizes
function photo_contest_setup_image_sizes() {
    add_image_size('photo-contest-thumb', 150, 150, true);
    add_image_size('photo-contest-medium', 300, 300, true);
}
add_action('after_setup_theme', 'photo_contest_setup_image_sizes');

// Required files
require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest.php';
require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-activator.php';
require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-deactivator.php';

// Activation Hook
register_activation_hook(__FILE__, ['Photo_Contest_Activator', 'activate']);

// Deactivation Hook
register_deactivation_hook(__FILE__, ['Photo_Contest_Deactivator', 'deactivate']);

// Initialize Plugin
function run_photo_contest() {
    if (class_exists('Photo_Contest')) {
        $plugin = new Photo_Contest();
        $plugin->run();
    }
}

// Load text domain and initialize plugin
add_action('init', function() {
    load_plugin_textdomain('photo-contest', false, dirname(plugin_basename(__FILE__)) . '/languages');
    run_photo_contest();
}, 10);

// Load BuddyPress Integration
function init_photo_contest_buddypress() {
    if (function_exists('buddypress')) {
        require_once PHOTO_CONTEST_PATH . 'includes/buddypress-integration.php';
        if (!isset($GLOBALS['photo_contest_bp'])) {
            $GLOBALS['photo_contest_bp'] = new Photo_Contest_BuddyPress();
        }
    }
}
add_action('bp_include', 'init_photo_contest_buddypress', 20);
