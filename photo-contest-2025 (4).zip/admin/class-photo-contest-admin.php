<?php

class Photo_Contest_Admin {
    private $plugin_name;
    private $version;
    private $contest_manager;

    // Status constants
    const SUBMISSION_STATUS_PENDING = 'pending';
    const SUBMISSION_STATUS_APPROVED = 'approved';
    const SUBMISSION_STATUS_REJECTED = 'rejected';

    // Menu slugs
    const MENU_SLUG = 'photo-contest';
    const SETTINGS_SLUG = 'photo-contest-settings';
    const NEW_CONTEST_SLUG = 'photo-contest-new';
    const EDIT_CONTEST_SLUG = 'photo-contest-edit';
    const SUBMISSIONS_SLUG = 'photo-contest-submissions';

    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        
        require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-manager.php';
        $this->contest_manager = new Photo_Contest_Manager();
        
        // Admin menu and page handlers
        add_action('admin_menu', array($this, 'add_plugin_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_styles'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_post_create_photo_contest', array($this, 'handle_contest_creation'));
        add_action('admin_post_update_photo_contest', array($this, 'handle_contest_update'));
        add_action('admin_post_delete_photo_contest', array($this, 'handle_contest_deletion'));
        add_action('admin_post_save_photo_contest_settings', array($this, 'handle_settings_save'));
        
        // AJAX handlers
        add_action('wp_ajax_approve_submission', array($this, 'handle_approve_submission'));
        add_action('wp_ajax_reject_submission', array($this, 'handle_reject_submission'));
        add_action('wp_ajax_bulk_submissions', array($this, 'handle_bulk_submissions'));
        add_action('wp_ajax_search_submissions', array($this, 'handle_submission_search'));
        
        // Export handler
        add_action('admin_post_export_submissions', array($this, 'export_submissions'));
    }

    public function enqueue_styles() {
        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/admin-style.css', array(), $this->version, 'all');
        wp_enqueue_style('jquery-ui-datepicker');
        
        $screen = get_current_screen();
        if ($screen && $screen->id === 'photo-contest_page_photo-contest-settings') {
            wp_enqueue_style(
                'photo-contest-settings',
                plugin_dir_url(__FILE__) . 'css/photo-contest-settings.css',
                array(),
                $this->version,
                'all'
            );
        }
    }

    public function enqueue_scripts() {
        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/admin-script.js', array('jquery'), $this->version, false);
        
        wp_localize_script($this->plugin_name, 'photoContest', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('photo_contest_nonce')
        ));

        $screen = get_current_screen();
        if ($screen && $screen->id === 'photo-contest_page_photo-contest-settings') {
            wp_enqueue_script(
                'photo-contest-settings',
                plugin_dir_url(__FILE__) . 'js/photo-contest-settings.js',
                array('jquery'),
                $this->version,
                true
            );
            wp_localize_script(
                'photo-contest-settings',
                'photoContestSettings',
                array(
                    'ajaxurl' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('photo_contest_settings_nonce'),
                    'strings' => array(
                        'saveSuccess' => __('Settings saved successfully!', 'photo-contest'),
                        'saveError' => __('Error saving settings.', 'photo-contest'),
                        'unsavedChanges' => __('You have unsaved changes.', 'photo-contest')
                    )
                )
            );
        }
    }

    public function add_plugin_admin_menu() {
        add_menu_page(
            'Photo Contest', 
            'Photo Contest', 
            'manage_options', 
            self::MENU_SLUG,
            array($this, 'display_plugin_admin_page'),
            'dashicons-format-gallery',
            30
        );

        add_submenu_page(
            self::MENU_SLUG,
            'All Contests',
            'All Contests',
            'manage_options',
            self::MENU_SLUG,
            array($this, 'display_plugin_admin_page')
        );

        add_submenu_page(
            self::MENU_SLUG,
            'Add New Contest',
            'Add New Contest',
            'manage_options',
            self::NEW_CONTEST_SLUG,
            array($this, 'display_add_new_contest')
        );

        add_submenu_page(
            self::MENU_SLUG,
            'Email Settings',
            'Email Settings',
            'manage_options',
            self::SETTINGS_SLUG,
            array($this, 'display_settings_page')
        );

        add_submenu_page(
            self::MENU_SLUG,
            'Submissions',
            'Submissions',
            'manage_options',
            'photo-contest-submissions',
            array($this, 'display_contest_submissions')
        );

        add_submenu_page(
            null,
            'Edit Contest',
            'Edit Contest',
            'manage_options',
            self::EDIT_CONTEST_SLUG,
            array($this, 'display_edit_contest')
        );
    }

    public function handle_approve_submission() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized', 403);
        }

        check_ajax_referer('photo_contest_nonce', 'nonce');

        $submission_id = intval($_POST['submission_id']);
        $result = $this->contest_manager->approve_submission($submission_id);

        if ($result) {
            wp_send_json_success(array(
                'message' => 'Submission approved successfully',
                'status' => 'approved'
            ));
        } else {
            wp_send_json_error('Failed to approve submission');
        }
    }

    public function handle_reject_submission() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized', 403);
        }

        check_ajax_referer('photo_contest_nonce', 'nonce');

        $submission_id = intval($_POST['submission_id']);
        $result = $this->contest_manager->reject_submission($submission_id);

        if ($result) {
            wp_send_json_success(array(
                'message' => 'Submission rejected successfully',
                'status' => 'rejected'
            ));
        } else {
            wp_send_json_error('Failed to reject submission');
        }
    }

    public function display_contest_submissions() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        $submissions = $this->contest_manager->get_all_submissions();
        ?>
        <div class="wrap">
            <h1>Photo Contest Submissions</h1>
            <div id="submission-status-message" class="notice" style="display: none;"></div>
            <table class="wp-list-table widefixed striped">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Submitted By</th>
                        <th>Photo</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $submission): ?>
                        <tr>
                            <td><?php echo esc_html($submission->title); ?></td>
                            <td><?php echo esc_html(get_userdata($submission->user_id)->display_name); ?></td>
                            <td><img src="<?php echo esc_url($submission->photo_url); ?>" width="100"></td>
                            <td><?php echo esc_html($submission->submission_date); ?></td>
                            <td><?php echo esc_html($submission->status); ?></td>
                            <td>
                                <button class="button approve-submission" data-id="<?php echo esc_attr($submission->id); ?>">Approve</button>
                                <button class="button reject-submission" data-id="<?php echo esc_attr($submission->id); ?>">Reject</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function handle_bulk_submissions() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized', 403);
        }

        check_ajax_referer('photo_contest_submission_nonce', 'nonce');
        
        $submission_ids = array_map('intval', $_POST['submission_ids']);
        $action = sanitize_text_field($_POST['bulk_action']);
        
        $results = [];
        foreach ($submission_ids as $id) {
            if ($action === 'approve') {
                $results[$id] = $this->contest_manager->approve_submission($id);
            } elseif ($action === 'reject') {
                $results[$id] = $this->contest_manager->reject_submission($id);
            }
        }
        wp_send_json_success($results);
    }

    public function handle_submission_search() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized', 403);
        }

        check_ajax_referer('photo_contest_submission_nonce', 'nonce');
        
        $search_term = sanitize_text_field($_POST['search']);
        $contest_id = intval($_POST['contest_id']);
        $results = $this->contest_manager->search_submissions($contest_id, $search_term);
        
        wp_send_json_success($results);
    }

    public function export_submissions() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        $contest_id = isset($_GET['contest_id']) ? intval($_GET['contest_id']) : 0;
        $submissions = $this->contest_manager->get_contest_submissions($contest_id);
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="contest-submissions.csv"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Title', 'Participant', 'Status', 'Date']);
        
        foreach ($submissions as $submission) {
            fputcsv($output, [
                $submission->id,
                $submission->title,
                $submission->participant_name,
                $submission->status,
                $submission->submission_date
            ]);
        }
        
        fclose($output);
        exit;
    }

    private function validate_contest_dates($start_date, $end_date) {
        $start = strtotime($start_date);
        $end = strtotime($end_date);
        
        return $start && $end && $start < $end;
    }

    private function log_error($message, $data = []) {
        if (WP_DEBUG) {
            error_log(sprintf(
                '[Photo Contest] %s | Data: %s',
                $message,
                json_encode($data)
            ));
        }
    }

    public function display_plugin_admin_page() {
        $contests = $this->contest_manager->get_all_contests();
        require_once plugin_dir_path(__FILE__) . 'partials/admin-display.php';
    }

    public function display_add_new_contest() {
        require_once plugin_dir_path(__FILE__) . 'partials/admin-new-contest.php';
    }

    public function display_edit_contest() {
        require_once plugin_dir_path(__FILE__) . 'partials/admin-edit-contest.php';
    }

    public function display_settings_page() {
        require_once plugin_dir_path(__FILE__) . 'partials/admin-settings.php';
    }
}
