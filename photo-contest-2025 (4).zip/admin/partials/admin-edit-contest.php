<?php
if (!defined('ABSPATH')) exit;

$contest_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$contest = $this->contest_manager->get_contest($contest_id);

if (!$contest) {
    wp_die('Contest not found');
}
?>

<div class="wrap photo-contest-admin">
    <h1>Edit Contest</h1>

    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" class="photo-contest-form">
        <input type="hidden" name="action" value="update_photo_contest">
        <input type="hidden" name="contest_id" value="<?php echo esc_attr($contest_id); ?>">
        <?php wp_nonce_field('update_photo_contest', 'photo_contest_nonce'); ?>

        <div class="form-field">
            <label for="contest-title">Contest Title *</label>
            <input type="text" id="contest-title" name="contest_title" value="<?php echo esc_attr($contest->title); ?>" required>
        </div>

        <div class="form-field">
            <label for="contest-description">Description</label>
            <textarea id="contest-description" name="contest_description" rows="5"><?php echo esc_textarea($contest->description); ?></textarea>
        </div>

        <div class="form-field">
            <label for="start-date">Start Date *</label>
            <input type="date" id="start-date" name="start_date" value="<?php echo esc_attr(date('Y-m-d', strtotime($contest->start_date))); ?>" required>
        </div>

        <div class="form-field">
            <label for="end-date">End Date *</label>
            <input type="date" id="end-date" name="end_date" value="<?php echo esc_attr(date('Y-m-d', strtotime($contest->end_date))); ?>" required>
        </div>

        <div class="form-field">
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="draft" <?php selected($contest->status, 'draft'); ?>>Draft</option>
                <option value="active" <?php selected($contest->status, 'active'); ?>>Active</option>
                <option value="completed" <?php selected($contest->status, 'completed'); ?>>Completed</option>
            </select>
        </div>

        <p class="submit">
            <input type="submit" name="submit" id="submit" class="button button-primary" value="Update Contest">
        </p>
    </form>
</div>
