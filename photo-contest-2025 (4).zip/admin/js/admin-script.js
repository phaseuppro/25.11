jQuery(document).ready(function($) {
    // Debug logging
    console.log('PhotoContest initialized:', photoContest);

    // Contest deletion confirmation
    $('.delete-contest').on('click', function(e) {
        if (!confirm('Are you sure you want to delete this contest?')) {
            e.preventDefault();
        }
    });

    // Datepicker initialization
    if ($.fn.datepicker) {
        $('.contest-date').datepicker({
            dateFormat: 'yy-mm-dd',
            minDate: 0
        });
    }

    // Form validation
    $('#new-contest-form').on('submit', function(e) {
        var title = $('#contest-title').val();
        var startDate = $('#start-date').val();
        var endDate = $('#end-date').val();

        if (!title || !startDate || !endDate) {
            e.preventDefault();
            alert('Please fill in all required fields');
        }
    });

    // Enhanced submission handling function
    function handleSubmissionAction(action, button, submissionId) {
        // Debug logging
        console.log('Starting submission action:', {
            action: action,
            submissionId: submissionId,
            nonce: photoContest.nonce
        });

        $.ajax({
            url: photoContest.ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: {
                action: action,
                submission_id: submissionId,
                nonce: photoContest.nonce
            },
            beforeSend: function() {
                console.log('Sending AJAX request');
                button.prop('disabled', true);
                showMessage('info', 'Processing...');
            },
            success: function(response) {
                console.log('AJAX response:', response);
                if (response.success) {
                    var newStatus = action === 'approve_submission' ? 'approved' : 'rejected';
                    var statusCell = button.closest('tr').find('td:eq(4)');
                    statusCell.text(newStatus);
                    statusCell.addClass('status-' + newStatus);
                    showMessage('success', 'Submission ' + newStatus + ' successfully');
                    button.closest('tr').find('button').prop('disabled', true);
                } else {
                    button.prop('disabled', false);
                    showMessage('error', response.data || 'Action failed');
                }
            },
            error: function(xhr, status, error) {
                console.log('AJAX Error:', {xhr: xhr, status: status, error: error});
                button.prop('disabled', false);
                showMessage('error', 'Network error occurred: ' + error);
            },
            complete: function() {
                console.log('AJAX request completed');
            }
        });
    }

    // Direct event handlers with debugging
    $(document).on('click', '.approve-submission', function(e) {
        e.preventDefault();
        console.log('Approve button clicked');
        var button = $(this);
        var submissionId = button.data('id');
        console.log('Submission ID:', submissionId);
        handleSubmissionAction('approve_submission', button, submissionId);
    });

    $(document).on('click', '.reject-submission', function(e) {
        e.preventDefault();
        console.log('Reject button clicked');
        var button = $(this);
        var submissionId = button.data('id');
        console.log('Submission ID:', submissionId);
        handleSubmissionAction('reject_submission', button, submissionId);
    });

    // Enhanced status message display function
    function showMessage(type, message) {
        var messageDiv = $('#submission-status-message');
        var typeClass = 'notice-' + (type === 'error' ? 'error' : 
                                   type === 'success' ? 'success' : 
                                   'info');
        
        messageDiv.removeClass()
                 .addClass('notice ' + typeClass)
                 .html('<p>' + message + '</p>')
                 .fadeIn();

        // Clear any existing timeout
        if (messageDiv.data('timeoutId')) {
            clearTimeout(messageDiv.data('timeoutId'));
        }

        // Set new timeout
        var timeoutId = setTimeout(function() {
            messageDiv.fadeOut();
        }, 3000);

        messageDiv.data('timeoutId', timeoutId);
    }

    // Bulk actions handling
    $('#bulk-action-form').on('submit', function(e) {
        e.preventDefault();
        var selectedSubmissions = $('.submission-checkbox:checked').map(function() {
            return $(this).val();
        }).get();

        if (selectedSubmissions.length === 0) {
            showMessage('error', 'Please select submissions to process');
            return;
        }

        var action = $('#bulk-action-select').val();
        if (!action) {
            showMessage('error', 'Please select an action');
            return;
        }

        handleBulkAction(action, selectedSubmissions);
    });

    // Search functionality
    $('#submission-search').on('input', function() {
        var searchTerm = $(this).val().toLowerCase();
        $('.submission-row').each(function() {
            var row = $(this);
            var text = row.text().toLowerCase();
            row.toggle(text.indexOf(searchTerm) > -1);
        });
    });

    // Initialize tooltips if available
    if ($.fn.tooltip) {
        $('[data-toggle="tooltip"]').tooltip();
    }
});
