jQuery(document).ready(function($) {
    // Preview email template functionality
    $('.preview-template').on('click', function(e) {
        e.preventDefault();
        const templateType = $(this).data('template');
        const templateContent = $(`#${templateType}_template`).val();
        
        $('#template-preview-content').html(templateContent);
        $('#template-preview-modal').show();
    });

    // Close preview modal
    $('.close-preview').on('click', function() {
        $('#template-preview-modal').hide();
    });

    // Close modal on escape key
    $(document).on('keyup', function(e) {
        if (e.key === "Escape") {
            $('#template-preview-modal').hide();
        }
    });

    // Variable insertion
    $('.insert-variable').on('click', function() {
        const variable = $(this).data('variable');
        const targetId = $(this).closest('.template-section').find('textarea').attr('id');
        const target = document.getElementById(targetId);
        
        if (target) {
            const startPos = target.selectionStart;
            const endPos = target.selectionEnd;
            const currentValue = $(target).val();
            const newValue = currentValue.substring(0, startPos) + 
                            '{' + variable + '}' + 
                            currentValue.substring(endPos);
            
            $(target).val(newValue);
            target.focus();
        }
    });

    // Save settings with AJAX
    $('#photo-contest-settings-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $submitButton = $form.find('input[type="submit"]');
        const formData = $form.serialize();
        
        // Disable submit button while saving
        $submitButton.prop('disabled', true);
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'save_photo_contest_settings',
                formData: formData,
                nonce: photoContestSettings.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#settings-saved-notice').fadeIn().delay(2000).fadeOut();
                } else {
                    $('#settings-error-notice').fadeIn().delay(2000).fadeOut();
                }
            },
            error: function() {
                $('#settings-error-notice').fadeIn().delay(2000).fadeOut();
            },
            complete: function() {
                // Re-enable submit button
                $submitButton.prop('disabled', false);
            }
        });
    });

    // Auto-save warning
    $(window).on('beforeunload', function() {
        const $form = $('#photo-contest-settings-form');
        if ($form.serialize() !== $form.data('original-state')) {
            return 'You have unsaved changes. Are you sure you want to leave?';
        }
    });

    // Store initial form state
    $('#photo-contest-settings-form').data('original-state', 
        $('#photo-contest-settings-form').serialize()
    );
});
