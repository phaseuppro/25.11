jQuery(document).ready(function($) {
    $('#photo-contest-form').on('submit', function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        formData.append('action', 'submit_contest_photo');
        
        $.ajax({
            url: photoContestBP.ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    alert(response.data);
                    location.reload();
                } else {
                    alert(response.data);
                }
            },
            error: function(xhr, status, error) {
                console.log(xhr.responseText);
                alert('Upload failed. Please try again.');
            }
        });
    });
});