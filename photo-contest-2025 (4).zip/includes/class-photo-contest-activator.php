<?php


class Photo_Contest_Activator {
    public static function activate() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // Contests table
        $contests_table = $wpdb->prefix . 'photo_contests';
        $sql1 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}photo_submissions (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    contest_id bigint(20) NOT NULL,
    user_id bigint(20) NOT NULL,
    photo_url varchar(255) NOT NULL,
    attachment_id bigint(20) NOT NULL,
    thumb_url varchar(255) NOT NULL,
    medium_url varchar(255) NOT NULL,
    title varchar(100) NOT NULL,
    description text,
    status varchar(20) NOT NULL,
    created_at datetime NOT NULL,
    PRIMARY KEY (id)
) $charset_collate;";

        // Submissions table
        $submissions_table = $wpdb->prefix . 'photo_contest_submissions';
        $sql2 = "CREATE TABLE IF NOT EXISTS $submissions_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            contest_id bigint(20) NOT NULL,
            user_id bigint(20) NOT NULL,
            title varchar(255) NOT NULL,
            description text,
            photo_url varchar(255) NOT NULL,
            participant_name varchar(100) NOT NULL,
            votes_count bigint(20) NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'pending',
            submission_date datetime NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY contest_id (contest_id),
            KEY user_id (user_id)
        ) $charset_collate;";

        // Votes table
        $votes_table = $wpdb->prefix . 'photo_contest_votes';
        $sql3 = "CREATE TABLE IF NOT EXISTS $votes_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            submission_id bigint(20) NOT NULL,
            user_id bigint(20) NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY submission_id (submission_id),
            KEY user_id (user_id),
            UNIQUE KEY unique_vote (submission_id, user_id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql1);
        dbDelta($sql2);
        dbDelta($sql3);

        // Set version in options
        add_option('photo_contest_db_version', '1.0.0');
    }
}
