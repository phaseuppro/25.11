$attachment_id = media_handle_upload('photo', 0);
$thumb = wp_get_attachment_image_src($attachment_id, 'photo-contest-thumb');