<?php
class Photo_Contest_Notifications {
    private $email_templates;

    public function __construct() {
        require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-email-templates.php';
        $this->email_templates = new Photo_Contest_Email_Templates();

        add_action('photo_contest_submission_approved', array($this, 'notify_submission_approved'), 10, 2);
        add_action('photo_contest_winner_selected', array($this, 'notify_contest_winner'), 10, 2);
        add_action('photo_contest_new_submission', array($this, 'notify_admin_new_submission'), 10, 2);
        add_filter('wp_mail_content_type', array($this, 'set_html_content_type'));
    }

    public function notify_submission_approved($submission_id, $user_id) {
        $user = get_userdata($user_id);
        $contest = $this->get_contest_by_submission($submission_id);
        
        $subject = __('Your photo submission has been approved!', 'photo-contest');
        $message = $this->email_templates->get_submission_approved_template(
            $user->display_name,
            $contest->title
        );

        wp_mail($user->user_email, $subject, $message);
    }

    public function notify_contest_winner($contest_id, $user_id) {
        $user = get_userdata($user_id);
        $contest = $this->get_contest($contest_id);
        
        $subject = sprintf(__('Congratulations! You won the %s contest!', 'photo-contest'), $contest->title);
        $message = $this->email_templates->get_winner_notification_template(
            $user->display_name,
            $contest->title,
            1 // Assuming first place, you can modify this as needed
        );

        wp_mail($user->user_email, $subject, $message);
    }

    public function notify_admin_new_submission($submission_id, $contest_id) {
        $admin_email = get_option('admin_email');
        $contest = $this->get_contest($contest_id);
        $submission = $this->get_submission($submission_id);
        $user = get_userdata($submission->user_id);
        
        $submission_details = array(
            'title' => $submission->title,
            'user_name' => $user->display_name,
            'date' => date_i18n(get_option('date_format'), strtotime($submission->created_at))
        );

        $subject = sprintf(__('New photo submission for %s', 'photo-contest'), $contest->title);
        $message = $this->email_templates->get_admin_notification_template(
            $contest->title,
            $submission_details
        );

        wp_mail($admin_email, $subject, $message);
    }

    public function set_html_content_type() {
        return 'text/html';
    }

    private function get_contest($contest_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'photo_contests';
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $contest_id));
    }

    private function get_submission($submission_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'photo_submissions';
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $submission_id));
    }

    private function get_contest_by_submission($submission_id) {
        global $wpdb;
        $submissions_table = $wpdb->prefix . 'photo_submissions';
        $contests_table = $wpdb->prefix . 'photo_contests';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT c.* FROM $contests_table c 
            JOIN $submissions_table s ON s.contest_id = c.id 
            WHERE s.id = %d",
            $submission_id
        ));
    }
}
