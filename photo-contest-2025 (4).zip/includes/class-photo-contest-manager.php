<?php

class Photo_Contest_Manager {
    private $wpdb;
    private $contests_table;
    private $submissions_table;
    private $votes_table;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->contests_table = $wpdb->prefix . 'photo_contests';
        $this->submissions_table = $wpdb->prefix . 'photo_contest_submissions';
        $this->votes_table = $wpdb->prefix . 'photo_contest_votes';
    }

    public function get_all_submissions() {
        return $this->wpdb->get_results(
            "SELECT s.*, u.display_name as participant_name 
            FROM {$this->submissions_table} s
            LEFT JOIN {$this->wpdb->users} u ON s.user_id = u.ID 
            ORDER BY s.submission_date DESC"
        );
    }

    public function create_contest($data) {
        return $this->wpdb->insert(
            $this->contests_table,
            array(
                'title' => sanitize_text_field($data['contest_title']),
                'description' => sanitize_textarea_field($data['contest_description']),
                'start_date' => $data['start_date'],
                'end_date' => $data['end_date'],
                'status' => 'draft',
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );
    }

    public function get_all_contests() {
        return $this->wpdb->get_results(
            "SELECT c.*, COUNT(s.id) as submission_count 
            FROM {$this->contests_table} c 
            LEFT JOIN {$this->submissions_table} s ON c.id = s.contest_id 
            GROUP BY c.id 
            ORDER BY c.created_at DESC"
        );
    }

    public function get_active_contests() {
        return $this->wpdb->get_results(
            "SELECT * FROM {$this->contests_table} 
            WHERE status = 'active' 
            AND start_date <= NOW() 
            AND end_date >= NOW() 
            ORDER BY end_date ASC"
        );
    }

    public function get_contest($id) {
        return $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->contests_table} WHERE id = %d",
                $id
            )
        );
    }

    public function update_contest($id, $data) {
        return $this->wpdb->update(
            $this->contests_table,
            array(
                'title' => sanitize_text_field($data['contest_title']),
                'description' => sanitize_textarea_field($data['contest_description']),
                'start_date' => $data['start_date'],
                'end_date' => $data['end_date'],
                'status' => $data['status'],
                'updated_at' => current_time('mysql')
            ),
            array('id' => $id),
            array('%s', '%s', '%s', '%s', '%s', '%s'),
            array('%d')
        );
    }

    public function delete_contest($id) {
        // Delete associated submissions first
        $this->wpdb->delete(
            $this->submissions_table,
            array('contest_id' => $id),
            array('%d')
        );

        // Then delete the contest
        return $this->wpdb->delete(
            $this->contests_table,
            array('id' => $id),
            array('%d')
        );
    }

    public function get_contest_submissions($contest_id, $args = []) {
        $defaults = [
            'status' => '',
            'orderby' => 'submission_date',
            'order' => 'DESC'
        ];
        
        $args = wp_parse_args($args, $defaults);
        
        $query = "SELECT s.*, u.display_name as participant_name 
                 FROM {$this->submissions_table} s 
                 LEFT JOIN {$this->wpdb->users} u ON s.user_id = u.ID 
                 WHERE s.contest_id = %d";
        
        if (!empty($args['status'])) {
            $query .= $this->wpdb->prepare(" AND s.status = %s", $args['status']);
        }
        
        $query .= " ORDER BY s.{$args['orderby']} {$args['order']}";
        
        return $this->wpdb->get_results($this->wpdb->prepare($query, $contest_id));
    }

    public function get_user_submissions($user_id) {
        return $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT s.*, c.title as contest_title 
                FROM {$this->submissions_table} s 
                JOIN {$this->contests_table} c ON s.contest_id = c.id 
                WHERE s.user_id = %d 
                ORDER BY s.submission_date DESC",
                $user_id
            )
        );
    }

    public function create_submission($data) {
        return $this->wpdb->insert(
            $this->submissions_table,
            [
                'contest_id' => $data['contest_id'],
                'user_id' => $data['user_id'],
                'title' => $data['title'],
                'photo_url' => $data['photo_url'],
                'thumb_url' => $data['thumb_url'],
                'medium_url' => $data['medium_url'],
                'status' => 'pending',
                'submission_date' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ],
            ['%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
        );
    }

    public function approve_submission($submission_id) {
        if (empty($submission_id)) {
            return false;
        }

        $current_status = $this->get_submission_status($submission_id);
        if ($current_status === 'approved') {
            return true;
        }

        $result = $this->wpdb->update(
            $this->submissions_table,
            array(
                'status' => 'approved',
                'updated_at' => current_time('mysql')
            ),
            array('id' => $submission_id),
            array('%s', '%s'),
            array('%d')
        );

        if ($result !== false) {
            do_action('photo_contest_submission_approved', $submission_id);
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("Photo Contest: Submission {$submission_id} approved successfully");
            }
            return true;
        }

        return false;
    }

    public function reject_submission($submission_id) {
        if (empty($submission_id)) {
            return false;
        }

        $current_status = $this->get_submission_status($submission_id);
        if ($current_status === 'rejected') {
            return true;
        }

        $result = $this->wpdb->update(
            $this->submissions_table,
            array(
                'status' => 'rejected',
                'updated_at' => current_time('mysql')
            ),
            array('id' => $submission_id),
            array('%s', '%s'),
            array('%d')
        );

        if ($result !== false) {
            do_action('photo_contest_submission_rejected', $submission_id);
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("Photo Contest: Submission {$submission_id} rejected successfully");
            }
            return true;
        }

        return false;
    }

    public function get_submission_status($submission_id) {
        return $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT status FROM {$this->submissions_table} WHERE id = %d",
                $submission_id
            )
        );
    }

    public function search_submissions($contest_id, $search_term) {
        return $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT s.*, u.display_name as participant_name 
                FROM {$this->submissions_table} s
                LEFT JOIN {$this->wpdb->users} u ON s.user_id = u.ID 
                WHERE s.contest_id = %d 
                AND (s.title LIKE %s OR u.display_name LIKE %s)",
                $contest_id,
                '%' . $this->wpdb->esc_like($search_term) . '%',
                '%' . $this->wpdb->esc_like($search_term) . '%'
            )
        );
    }

    public function get_submission_votes($submission_id) {
        return $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->votes_table} WHERE submission_id = %d",
                $submission_id
            )
        );
    }

    public function add_vote($submission_id, $user_id) {
        if ($this->has_user_voted($submission_id, $user_id)) {
            return false;
        }

        return $this->wpdb->insert(
            $this->votes_table,
            [
                'submission_id' => $submission_id,
                'user_id' => $user_id,
                'created_at' => current_time('mysql')
            ],
            ['%d', '%d', '%s']
        );
    }

    public function has_user_voted($submission_id, $user_id) {
        return $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->votes_table} 
                WHERE submission_id = %d AND user_id = %d",
                $submission_id,
                $user_id
            )
        ) > 0;
    }

    public function get_contest_submission_count($contest_id) {
        return $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->submissions_table} WHERE contest_id = %d",
                $contest_id
            )
        );
    }
}
