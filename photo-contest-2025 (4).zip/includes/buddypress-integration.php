<?php
if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'class-photo-contest-manager.php';

class Photo_Contest_BuddyPress {
    private $contest_manager;
    const SUBMISSION_LOG = WP_CONTENT_DIR . '/photo-contest-debug.log';
    const DISPLAY_LOG = WP_CONTENT_DIR . '/my-custom-debug.log';

    public function __construct() {
    error_log('Debug log location: ' . WP_CONTENT_DIR . '/debug.log');
    error_log('Photo Contest Plugin: Constructor called');
    
    $this->contest_manager = new Photo_Contest_Manager();
    error_log('Contest Manager Initialized: ' . ($this->contest_manager ? 'Yes' : 'No'));
    
    add_action('init', array($this, 'load_textdomain'));
    add_action('bp_setup_nav', array($this, 'setup_nav'), 100);
    add_action('bp_setup_admin_bar', array($this, 'setup_admin_bar'), 100);
    add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    add_action('wp_ajax_submit_contest_photo', array($this, 'handle_photo_submission'));
}

    public function load_textdomain() {
        load_plugin_textdomain('photo-contest', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    public function setup_nav() {
        bp_core_new_nav_item(array(
            'name'                => __('Photo Contests', 'photo-contest'),
            'slug'                => 'photo-contests',
            'position'            => 80,
            'screen_function'     => array($this, 'display_contest_tab'),
            'default_subnav_slug' => 'upload-photos',
            'item_css_id'         => 'photo-contests-main'
        ));

        bp_core_new_subnav_item(array(
            'name'            => __('Upload Photos', 'photo-contest'),
            'slug'            => 'upload-photos',
            'parent_url'      => trailingslashit(bp_displayed_user_domain() . 'photo-contests'),
            'parent_slug'     => 'photo-contests',
            'screen_function' => array($this, 'display_upload_tab'),
            'position'        => 5,
            'item_css_id'     => 'photo-contests-upload'
        ));

        bp_core_new_subnav_item(array(
            'name'            => __('My Submissions', 'photo-contest'),
            'slug'            => 'my-submissions',
            'parent_url'      => trailingslashit(bp_displayed_user_domain() . 'photo-contests'),
            'parent_slug'     => 'photo-contests',
            'screen_function' => array($this, 'display_submissions_tab'),
            'position'        => 10,
            'item_css_id'     => 'photo-contests-submissions'
        ));

        bp_core_new_subnav_item(array(
            'name'            => __('Contest Results', 'photo-contest'),
            'slug'            => 'contest-results',
            'parent_url'      => trailingslashit(bp_displayed_user_domain() . 'photo-contests'),
            'parent_slug'     => 'photo-contests',
            'screen_function' => array($this, 'display_results_tab'),
            'position'        => 15,
            'item_css_id'     => 'photo-contests-results'
        ));
    }

    public function display_contest_tab() {
        if (bp_is_current_action('upload-photos')) {
            $this->display_upload_tab();
        } elseif (bp_is_current_action('contest-results')) {
            $this->display_results_tab();
        } else {
            $this->display_submissions_tab();
        }
    }

    public function display_upload_tab() {
        add_action('bp_template_content', array($this, 'show_upload_content'));
        bp_core_load_template(apply_filters('bp_core_template_plugin', 'members/single/plugins'));
    }

    public function display_submissions_tab() {
        add_action('bp_template_content', array($this, 'show_submissions_content'));
        bp_core_load_template(apply_filters('bp_core_template_plugin', 'members/single/plugins'));
    }

    public function display_results_tab() {
        add_action('bp_template_content', array($this, 'show_results_content'));
        bp_core_load_template(apply_filters('bp_core_template_plugin', 'members/single/plugins'));
    }

    public function setup_admin_bar() {
        global $wp_admin_bar;
        if (!is_user_logged_in()) return;

        $wp_admin_bar->add_menu(array(
            'parent' => 'my-account-buddypress',
            'id'     => 'my-account-photo-contests',
            'title'  => __('Photo Contests', 'photo-contest'),
            'href'   => trailingslashit(bp_loggedin_user_domain() . 'photo-contests')
        ));
    }

    public function show_upload_content() {
        $contests = $this->contest_manager->get_active_contests();
        include(PHOTO_CONTEST_PATH . 'public/templates/submission-form.php');
    }
public function show_results_content() {
    try {
        global $wpdb;
        
        // Verify table existence
        $table_name = $wpdb->prefix . 'photo_contest_submissions';
        if (!$wpdb->get_var("SHOW TABLES LIKE '$table_name'")) {
            throw new Exception("Contest submissions table not found");
        }
        
        $contests = $this->contest_manager->get_active_contests();
        $results = $wpdb->get_results("
            SELECT s.*, c.title as contest_title, u.display_name 
            FROM {$wpdb->prefix}photo_contest_submissions s
            JOIN {$wpdb->prefix}photo_contests c ON s.contest_id = c.id
            JOIN {$wpdb->users} u ON s.user_id = u.ID
            ORDER BY s.votes DESC
        ");
        
        if ($wpdb->last_error) {
            throw new Exception($wpdb->last_error);
        }
        
        include(PHOTO_CONTEST_PATH . 'public/templates/contest-results.php');
        
    } catch (Exception $e) {
        error_log('Photo Contest Results Error: ' . $e->getMessage());
        echo '<div class="error">Unable to load contest results. Please try again later.</div>';
    }
}

public function show_submissions_content() {
    try {
        $log_file = WP_CONTENT_DIR . '/my-custom-debug.log';
        
        // Create directory if it doesn't exist
        if (!file_exists(dirname($log_file))) {
            mkdir(dirname($log_file), 0755, true);
        }
        
        // Add timestamp to log
        $log_message = "[" . date('Y-m-d H:i:s') . "] Starting submission content display\n";
        file_put_contents($log_file, $log_message, FILE_APPEND | LOCK_EX);
        
        global $wpdb;
        $user_id = bp_displayed_user_id();
        file_put_contents($log_file, "[User] ID: {$user_id}\n", FILE_APPEND);
        
        // Check if table exists
        $table_name = $wpdb->prefix . 'photo_contest_submissions';
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'");
        file_put_contents($log_file, "[Table] Exists: " . ($table_exists ? 'Yes' : 'No') . "\n", FILE_APPEND);
        
        if (!$table_exists) {
            throw new Exception("Required database table does not exist: {$table_name}");
        }
        
        // Get submissions
        $query = $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}photo_contest_submissions 
            WHERE user_id = %d 
            ORDER BY created_at DESC",
            $user_id
        );
        
        file_put_contents($log_file, "[Query] " . $query . "\n", FILE_APPEND);
        
        $user_submissions = $wpdb->get_results($query);
        
        if ($wpdb->last_error) {
            throw new Exception("Database error: " . $wpdb->last_error);
        }
        
        file_put_contents($log_file, "[Results] Count: " . count($user_submissions) . "\n", FILE_APPEND);
        
        $user_submissions = $user_submissions ?: array();
        
    } catch (Exception $e) {
        file_put_contents($log_file, "[Error] " . $e->getMessage() . "\n", FILE_APPEND);
        $user_submissions = array();
    }

    include(PHOTO_CONTEST_PATH . 'public/templates/contest-gallery.php');
}



public function handle_photo_submission() {
    $log_file = WP_CONTENT_DIR . '/photo-contest-debug.log';
    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Photo submission started\n", FILE_APPEND);
    
    try {
        if (!check_ajax_referer('photo_contest_submission', 'submission_nonce', false)) {
            file_put_contents($log_file, "Nonce verification failed\n", FILE_APPEND);
            wp_send_json_error('Security check failed');
            return;
        }
if (!isset($_FILES['photo'])) {
    throw new Exception('No photo uploaded');
}

$file = $_FILES['photo'];
$max_size = 5 * 1024 * 1024; // 5MB
$allowed_types = ['image/jpeg', 'image/png', 'image/gif'];

if ($file['size'] > $max_size) {
    throw new Exception('File size exceeds limit of 5MB');
}

if (!in_array($file['type'], $allowed_types)) {
    throw new Exception('Invalid file type. Please upload JPG, PNG or GIF');
}

        if (!is_user_logged_in()) {
            throw new Exception('Must be logged in');
        }

        file_put_contents($log_file, "POST data: " . print_r($_POST, true) . "\n", FILE_APPEND);
        file_put_contents($log_file, "FILES data: " . print_r($_FILES, true) . "\n", FILE_APPEND);

        $user_id = get_current_user_id();
        $contest_id = intval($_POST['contest_id']);
        
        if (!isset($_FILES['photo'])) {
            throw new Exception('No photo uploaded');
        }

        $attachment_id = media_handle_upload('photo', 0);
        if (is_wp_error($attachment_id)) {
            throw new Exception($attachment_id->get_error_message());
        }

        $submission_data = [
            'user_id' => $user_id,
            'contest_id' => $contest_id,
            'title' => sanitize_text_field($_POST['photo_title']),
            'description' => sanitize_textarea_field($_POST['photo_description']),
            'photo_url' => wp_get_attachment_url($attachment_id)
        ];

        file_put_contents($log_file, "Submission data: " . print_r($submission_data, true) . "\n", FILE_APPEND);

        $result = $this->contest_manager->create_submission($submission_data);

        if (!$result) {
            throw new Exception('Error saving submission');
        }

        file_put_contents($log_file, "Submission successful\n", FILE_APPEND);
        wp_send_json_success('Photo submitted successfully!');

    } catch (Exception $e) {
        file_put_contents($log_file, "Error: " . $e->getMessage() . "\n", FILE_APPEND);
        wp_send_json_error($e->getMessage());
    }
}


    public function enqueue_scripts() {
    if (bp_is_current_component('photo-contests')) {
        wp_enqueue_style('photo-contest-bp', PHOTO_CONTEST_URL . 'assets/css/buddypress.css', array(), '1.0.0');
        wp_enqueue_script('photo-contest-bp', PHOTO_CONTEST_URL . 'assets/js/buddypress.js', array('jquery'), '1.0.0', true);
        wp_localize_script('photo-contest-bp', 'photoContestBP', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('photo_contest_submission')
        ));
    }
}
}

add_action('bp_include', function() {
    if (function_exists('buddypress')) {
        global $photo_contest_bp;
        $photo_contest_bp = new Photo_Contest_BuddyPress();
    }
});
