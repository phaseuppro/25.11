<?php
class Photo_Contest {
    protected $loader;
    protected $plugin_name;
    protected $version;
    protected $results;
    protected $notifications;
    protected $settings;
    protected $contest_manager;
    protected $ajax_handler;

    public function __construct() {
        $this->version = PHOTO_CONTEST_VERSION;
        $this->plugin_name = 'photo-contest';
        
        $this->load_dependencies();
        $this->init_components();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }

    private function load_dependencies() {
    // Include files
    require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-loader.php';
    require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-defaults.php';
    require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-email-templates.php';
    require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-manager.php';
    require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-notifications.php';
    require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-results.php';
    require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-shortcodes.php';
    require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-submission.php';
    require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-voting.php';
    require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-ajax.php';

    // Admin files
    require_once PHOTO_CONTEST_PATH . 'admin/class-photo-contest-admin.php';
    require_once PHOTO_CONTEST_PATH . 'admin/class-photo-contest-settings.php';

    // Public files
    require_once PHOTO_CONTEST_PATH . 'public/class-photo-contest-public.php';
    
    $this->loader = new Photo_Contest_Loader();
}

protected function handle_photo_upload($file) {
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    
    // Set up custom upload parameters
    add_filter('upload_dir', array($this, 'custom_upload_directory'));
    
    $attachment_id = media_handle_upload($file, 0, array(
        'post_title' => sanitize_file_name($file['name']),
        'post_content' => '',
        'post_status' => 'inherit'
    ));
    
    // Remove custom upload directory filter
    remove_filter('upload_dir', array($this, 'custom_upload_directory'));
    
    if (!is_wp_error($attachment_id)) {
        // Generate thumbnails
        $metadata = wp_generate_attachment_metadata($attachment_id, get_attached_file($attachment_id));
        wp_update_attachment_metadata($attachment_id, $metadata);
        
        // Store additional contest-specific metadata
        update_post_meta($attachment_id, '_photo_contest_submission', true);
        update_post_meta($attachment_id, '_photo_contest_date', current_time('mysql'));
        
        return $attachment_id;
    }
    return false;
}

// Add this new method to handle custom upload directory
protected function custom_upload_directory($uploads) {
    $custom_dir = '/photo-contest/' . date('Y/m');
    $uploads['subdir'] = $custom_dir;
    $uploads['path'] = $uploads['basedir'] . $custom_dir;
    $uploads['url'] = $uploads['baseurl'] . $custom_dir;
    
    return $uploads;
}



    private function init_components() {
        $this->init_results();
        $this->init_notifications();
        $this->init_settings();
        $this->init_contest_manager();
        $this->init_ajax_handler();
    }

    private function init_results() {
        $this->results = new Photo_Contest_Results();
    }

    private function init_notifications() {
        $this->notifications = new Photo_Contest_Notifications();
    }

    private function init_settings() {
        $this->settings = new Photo_Contest_Settings();
    }

    private function init_contest_manager() {
        $this->contest_manager = new Photo_Contest_Manager();
    }

    private function init_ajax_handler() {
        $this->ajax_handler = new Photo_Contest_Ajax();
    }

    private function set_locale() {
        add_action('init', array($this, 'load_plugin_textdomain'));
    }

    public function load_plugin_textdomain() {
        load_plugin_textdomain(
            'photo-contest',
            false,
            dirname(plugin_basename(PHOTO_CONTEST_PATH)) . '/languages/'
        );
    }

    private function define_admin_hooks() {
        $plugin_admin = new Photo_Contest_Admin($this->get_plugin_name(), $this->get_version());
        
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');
        
        // Add settings hooks
        $this->loader->add_action('admin_init', $this->settings, 'register_settings');
        $this->loader->add_action('admin_menu', $this->settings, 'add_settings_page');
    }

    private function define_public_hooks() {
        $plugin_public = new Photo_Contest_Public($this->get_plugin_name(), $this->get_version());
        
        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_styles');
        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_scripts');
        
        // Add contest display hooks
        $this->loader->add_action('init', $plugin_public, 'register_shortcodes');
        $this->loader->add_action('wp_ajax_submit_photo', $plugin_public, 'handle_photo_submission');
        $this->loader->add_action('wp_ajax_vote_photo', $plugin_public, 'handle_photo_vote');
    }

    public function run() {
        $this->loader->run();
    }

    public function get_plugin_name() {
        return $this->plugin_name;
    }

    public function get_version() {
        return $this->version;
    }

    public function get_contest_manager() {
        return $this->contest_manager;
    }

    public function get_ajax_handler() {
        return $this->ajax_handler;
    }
}
