<?php
class Photo_Contest_Defaults {
    public static function get_default_templates() {
        return array(
            'submission_approved_template' => self::get_submission_approved_template(),
            'winner_notification_template' => self::get_winner_notification_template()
        );
    }

    private static function get_submission_approved_template() {
        return <<<EOT
Dear {user_name},

Great news! Your photo submission for the contest "{contest_title}" has been approved.

Your photo "{photo_title}" is now live in the gallery and ready for voting.

Thank you for participating!

Best regards,
The Contest Team
EOT;
    }

    private static function get_winner_notification_template() {
        return <<<EOT
Congratulations {user_name}!

We're excited to inform you that your photo "{photo_title}" has won {position} place in the "{contest_title}" contest!

Thank you for your amazing contribution to our photo contest.

Best regards,
The Contest Team
EOT;
    }
}
