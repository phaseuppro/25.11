<?php
if (!defined('ABSPATH')) exit;

class Photo_Contest_BuddyPress {
    private $contest_manager;
    
    public function __construct() {
        $this->contest_manager = new Photo_Contest_Manager();
        add_action('wp_ajax_submit_contest_photo', array($this, 'handle_photo_submission'));
        add_action('bp_setup_nav', array($this, 'setup_nav'), 100);
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    public function setup_nav() {
    bp_core_new_nav_item(array(
        'name' => __('Photo Contests', 'photo-contest'),
        'slug' => 'photo-contests',
        'position' => 80,
        'screen_function' => array($this, 'display_upload_tab'), // Changed this line
        'default_subnav_slug' => 'upload'
    ));

    bp_core_new_subnav_item(array(
        'name' => __('Upload Photos', 'photo-contest'),
        'slug' => 'upload',  // Simplified slug
        'parent_url' => bp_displayed_user_domain() . 'photo-contests/',
        'parent_slug' => 'photo-contests',
        'screen_function' => array($this, 'display_upload_tab'),
        'position' => 10
    ));
}

    public function display_contest_tab() {
        add_action('bp_template_content', array($this, 'show_upload_content'));
        bp_core_load_template('members/single/plugins');
    }

    public function display_upload_tab() {
        add_action('bp_template_content', array($this, 'show_upload_content'));
        bp_core_load_template('members/single/plugins');
    }

    public function show_upload_content() {
        include(PHOTO_CONTEST_PATH . 'public/templates/submission-form.php');
    }
    
    public function handle_photo_submission() {
    try {
        if (!check_ajax_referer('photo_contest_submission', 'submission_nonce', false)) {
            wp_send_json_error('Security check failed');
            return;
        }

        if (!is_user_logged_in()) {
            throw new Exception('Must be logged in');
        }

        $user_id = get_current_user_id();
        
        if (!isset($_FILES['photo'])) {
            throw new Exception('No photo uploaded');
        }

        $attachment_id = media_handle_upload('photo', 0);
        if (is_wp_error($attachment_id)) {
            throw new Exception($attachment_id->get_error_message());
        }

        $result = $this->contest_manager->create_submission([
            'user_id' => $user_id,
            'title' => sanitize_text_field($_POST['photo_title']),
            'photo_url' => wp_get_attachment_url($attachment_id)
        ]);

        if (!$result) {
            throw new Exception('Error saving submission');
        }

        wp_send_json_success('Photo submitted successfully!');

    } catch (Exception $e) {
        wp_send_json_error($e->getMessage());
    }
}


    public function enqueue_scripts() {
    if (bp_is_current_component('photo-contests')) {
        // Enqueue JavaScript
        wp_enqueue_script('photo-contest-bp', PHOTO_CONTEST_URL . 'public/js/buddypress.js', array('jquery'), '1.0.0', true);
        wp_localize_script('photo-contest-bp', 'photoContestBP', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('photo_contest_submission')
        ));
        
        // Enqueue CSS
        wp_enqueue_style('photo-contest-submission', PHOTO_CONTEST_URL . 'public/css/submission-style.css', array(), '1.0.0');
    }
}

}

new Photo_Contest_BuddyPress();
