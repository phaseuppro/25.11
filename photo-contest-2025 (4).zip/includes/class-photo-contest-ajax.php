<?php
class Photo_Contest_Ajax {
    public function __construct() {
        add_action('wp_ajax_save_photo_contest_settings', array($this, 'save_settings'));
    }

    public function save_settings() {
        check_ajax_referer('photo_contest_settings_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        parse_str($_POST['formData'], $settings);
        
        $sanitized_settings = array(
            'submission_approved_template' => wp_kses_post($settings['photo_contest_email_settings']['submission_approved_template']),
            'winner_notification_template' => wp_kses_post($settings['photo_contest_email_settings']['winner_notification_template']),
            'admin_notification_template' => wp_kses_post($settings['photo_contest_email_settings']['admin_notification_template'])
        );

        update_option('photo_contest_email_settings', $sanitized_settings);
        wp_send_json_success('Settings saved successfully');
    }
}
