<?php
class Photo_Contest_Submission {
    private $wpdb;
    private $submissions_table;
    private $upload_dir;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->submissions_table = $wpdb->prefix . 'photo_submissions';
        $this->upload_dir = wp_upload_dir();

        add_action('admin_post_submit_photo_contest', array($this, 'handle_submission'));
        add_action('admin_post_nopriv_submit_photo_contest', array($this, 'handle_submission'));
    }

    public function handle_submission() {
        if (!isset($_POST['photo_contest_nonce']) || 
            !wp_verify_nonce($_POST['photo_contest_nonce'], 'submit_photo_contest')) {
            wp_die('Security check failed');
        }

        $contest_id = intval($_POST['contest_id']);
        $user_id = get_current_user_id();
        
        $upload_result = $this->handle_photo_upload($_FILES['photo_file']);

        if (is_wp_error($upload_result)) {
            wp_die($upload_result->get_error_message());
        }

        // Verify thumbnails were generated
        $thumbnails = $this->verify_thumbnails($upload_result['attachment_id']);
        
        $submission_data = array(
            'contest_id' => $contest_id,
            'user_id' => $user_id,
            'photo_url' => $upload_result['url'],
            'attachment_id' => $upload_result['attachment_id'],
            'thumb_url' => $thumbnails['thumb'][0],
            'medium_url' => $thumbnails['medium'][0],
            'title' => sanitize_text_field($_POST['photo_title']),
            'description' => sanitize_textarea_field($_POST['photo_description']),
            'status' => 'pending',
            'created_at' => current_time('mysql')
        );

        $result = $this->wpdb->insert(
            $this->submissions_table,
            $submission_data,
            array(
                '%d', // contest_id
                '%d', // user_id
                '%s', // photo_url
                '%d', // attachment_id
                '%s', // thumb_url
                '%s', // medium_url
                '%s', // title
                '%s', // description
                '%s', // status
                '%s'  // created_at
            )
        );

        if ($result) {
            wp_redirect(add_query_arg('submitted', 'true', wp_get_referer()));
        } else {
            wp_die('Submission failed');
        }
        exit;
    }

    private function handle_photo_upload($file) {
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        $allowed_types = array('image/jpeg', 'image/png', 'image/gif');
        
        if (!in_array($file['type'], $allowed_types)) {
            return new WP_Error('invalid_type', 'Invalid file type. Please upload a JPEG, PNG or GIF image.');
        }

        if ($file['size'] > 5242880) {
            return new WP_Error('invalid_size', 'File too large. Maximum size is 5MB.');
        }

        $attachment_id = media_handle_upload('photo_file', 0, array(
            'post_title' => sanitize_file_name($file['name']),
            'post_status' => 'inherit'
        ));

        if (is_wp_error($attachment_id)) {
            return $attachment_id;
        }

        // Force regenerate thumbnails
        $attached_file = get_attached_file($attachment_id);
        $metadata = wp_generate_attachment_metadata($attachment_id, $attached_file);
        wp_update_attachment_metadata($attachment_id, $metadata);

        return array(
            'url' => wp_get_attachment_url($attachment_id),
            'attachment_id' => $attachment_id
        );
    }

    private function verify_thumbnails($attachment_id) {
        $metadata = wp_get_attachment_metadata($attachment_id);
        error_log('Generated Sizes: ' . print_r($metadata['sizes'], true));
        
        $thumb = wp_get_attachment_image_src($attachment_id, 'photo-contest-thumb');
        $medium = wp_get_attachment_image_src($attachment_id, 'photo-contest-medium');
        
        if (!$thumb || !$medium) {
            // Force regenerate if thumbnails are missing
            $attached_file = get_attached_file($attachment_id);
            $metadata = wp_generate_attachment_metadata($attachment_id, $attached_file);
            wp_update_attachment_metadata($attachment_id, $metadata);
            
            $thumb = wp_get_attachment_image_src($attachment_id, 'photo-contest-thumb');
            $medium = wp_get_attachment_image_src($attachment_id, 'photo-contest-medium');
        }
        
        return array(
            'thumb' => $thumb,
            'medium' => $medium
        );
    }

    public function display_photo($submission, $size = 'thumb') {
        $url = ($size === 'thumb') ? $submission->thumb_url : $submission->medium_url;
        
        return sprintf(
            '<div class="photo-contest-entry">
                <img src="%s" class="photo-contest-thumbnail" loading="lazy" />
                <div class="photo-meta">
                    <h3>%s</h3>
                    <span class="photo-author">By: %s</span>
                </div>
            </div>',
            esc_url($url),
            esc_html($submission->title),
            esc_html(get_the_author_meta('display_name', $submission->user_id))
        );
    }

    public function display_gallery($contest_id) {
        $submissions = $this->get_submissions($contest_id);
        $output = '<div class="photo-contest-gallery">';
        
        foreach ($submissions as $submission) {
            $output .= $this->display_photo($submission);
        }
        
        $output .= '</div>';
        return $output;
    }

    public function get_submissions($contest_id) {
        return $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->submissions_table} WHERE contest_id = %d ORDER BY created_at DESC",
                $contest_id
            )
        );
    }
}
